# Rage Edition Menu — Geode mod

This is a Geode mod project for Geometry Dash 2.2081. It is designed for Android and also declares the other supported 2.2081 platforms.

## Build

Install the Geode SDK and CLI, then run `geode build` in this folder. The resulting `.geode` package can be installed through Geode.
